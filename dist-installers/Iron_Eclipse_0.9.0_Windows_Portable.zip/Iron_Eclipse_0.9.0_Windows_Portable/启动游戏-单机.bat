@echo off
start "" "%~dp0client\index.html"
pause
