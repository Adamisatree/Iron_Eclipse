@echo off
chcp 65001 >nul
title Iron Eclipse - Windows Portable
where node >nul 2>&1
if %errorlevel% neq 0 (
  echo 未检测到 Node，请安装 https://nodejs.org/
  pause
  exit /b
)
echo 启动服务器...
set GAME_PORT=27015
start "Iron Eclipse Server" cmd /k "cd /d \"%~dp0server\" && node dist/index.js"
timeout /t 2 >nul
start "" "http://localhost:5173"
cd /d "%~dp0"
npx --yes serve -s client -l 5173
pause
