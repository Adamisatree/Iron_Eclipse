@echo off
cd /d "%~dp0server"
set GAME_PORT=27015
node dist/index.js
pause
